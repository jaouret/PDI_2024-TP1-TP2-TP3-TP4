// API Necesarias (antes les decíamos preprocesamiento con includes)
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <arpa/inet.h>

// Elegimos nro de Puerto y tamaño del bloque de información que vamos a mover entre el S y el C.
#define PUERTO 7801// #de puerto del servidor
#define BUFFER_SIZE 1024

// Estructuras y variables
int main(int argc, char const *argv[]) {
  struct sockaddr_in direccion;
  int cliente_sd = 0, leovalor;
  struct sockaddr_in serv_dir;
  char *mensaje = "Mensaje desde el cliente";
  char buffer[BUFFER_SIZE] = {0};
  
  // Creo el socket de flujo
  if ((cliente_sd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
    printf("\n Error : No se pudo crear el socket \n");
    return -1;
  }
  memset(&serv_dir, '0', sizeof(serv_dir));
  serv_dir.sin_family = AF_INET;
  serv_dir.sin_port = htons(PUERTO);
  // Conversión de la dirección IP de IPv4 en formato de cadena a binario
  if (inet_pton(AF_INET, "127.0.0.1", &serv_dir.sin_addr) <= 0) {
      printf("\nDirección Inválidad\n");
      return -1;
  }
  // Conectarse al servidor
  if (connect(cliente_sd, (struct sockaddr *)&serv_dir, sizeof(serv_dir)) < 0) {
     printf("\nFalla en la conexión \n");
     return -1;
  }
  // Crear múltiples conexiones utilizando fork()
    for (int i = 0; i < 5; ++i) {
        pid_t pid = fork();
        if (pid == -1) {
            perror("fork");
            exit(EXIT_FAILURE);
        } else if (pid == 0) { // Proceso hijo
            printf("Proceso hijo %d creando conexión...\n", getpid());

            // Enviar mensaje al servidor
            sprintf(buffer, "Mensaje desde el cliente %d\n", getpid());
            send(cliente_sd, buffer, strlen(buffer), 0);
            printf("Proceso hijo %d: Mensaje enviado al servidor\n", getpid());

            // Recibir respuesta del servidor
            int bytes_recibidos = recv(cliente_sd, buffer, BUFFER_SIZE, 0);
            if (bytes_recibidos > 0) {
                buffer[bytes_recibidos] = '\0';
                printf("Proceso hijo %d: Respuesta del servidor: %s\n", getpid(), buffer);
            } else if (bytes_recibidos == 0) {
                printf("Proceso hijo %d: Conexión cerrada por el servidor\n", getpid());
            } else {
                perror("recv");
            }

            // Cerrar el socket y terminar el proceso hijo
            close(cliente_sd);
            exit(EXIT_SUCCESS);
        }
    }

    // Esperar a que todos los procesos hijos terminen
    for (int i = 0; i < 5; ++i) {
        wait(NULL);
    }

    // Cerrar el socket del padre
    close(cliente_sd);
    return 0;
}
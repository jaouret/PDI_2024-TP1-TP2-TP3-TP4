
import socket
import time
import os

def main():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_ICMP)
    try:
        print("Conectado al servidor")
        
        while True:
            try:
                # Define the raw packet (header + payload)
                icmp_packet = b'\x08\x00\x42\x07\x00\x0b\x00\x00\x00\x00\x00\x10\x11\x12\x13\x14\x15\x16\x17' \
                              b'\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f\x21\x22\x23\x24\x25\x26\x27\x28\x29\x2a\x2b' \
                              b'\x2c\x2d\x2e\x2f\x30\x31\x32\x33\x34\x35\x36\x37'

                start_time = time.time()
                client_socket.sendto(icmp_packet, ("127.0.0.1", 0))
                print("Raw packet sent successfully!!")  
                
                # ICMP packets do not elicit a response like TCP or UDP, so receiving a response may not be applicable
                
                end_time = time.time()
                execution_time = end_time - start_time
                client_pid = os.getpid()
                server_pid = os.getppid()

                print("Tiempo de ejecución:", execution_time, "segundos")
                print("PID del cliente:", client_pid)
                print("PID del servidor:", server_pid)
            except ValueError:
                print("Error icmp_packet cannot reach server.")
    finally:
        client_socket.close()

if __name__ == "__main__":
    main()



